export { GetImage as default } from './GetImage';

