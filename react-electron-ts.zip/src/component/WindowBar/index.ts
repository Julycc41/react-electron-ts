export { WindowBar as default } from "./WindowBar";
