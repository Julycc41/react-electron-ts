
// [飞行方向控制]
export enum PlaneControl {
  "zuoshang" = "0",
  "shang" = "1",
  "youshang" = "2",
  "you" = "3",
  "shuaxin" = "4",
  "zuo" = "5",
  "107fangxiang_zuoxia" = "6",
  "xia" = "7",
  "youxia" = "8",
}

// [飞行操作控制]
export enum OperationControl {
  "fangda" = "12",
  "xiangji" = "13",
  "suoxiao" = "14",
}